import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './components/HomePage';
import CustomerRegisterForm from './components/CustomerRegisterForm';
import CustomerDetailsPage from './components/CustomerDetailsPage';
import RegisterUser from './components/RegisterUser';
import UserDetailsPage from './components/UserDetailsPage';
import SignInUser from './components/SignInUser';
import SignInCustomer from './components/SignInCustomer';
import ProductPage from './components/ProductPage';
import OrderPage from './components/OrderPage'; 
import CustomerHomePage from './components/CustomerHomePage'; 
import SupplierPage from './components/SupplierPage';
import DeliveryPage from './components/DeliveryPage';
import CustomerFeedbackPage from './components/CustomerFeedbackPage';



import './index.css';

function App() {
  return (
    <Router>
      <div className="app-wrapper">
        <div className="text-center">
          <h1>Urban Food Portal</h1>
          <Routes>
            {/* Customers */}
            <Route path="/customer-register" element={<CustomerRegisterForm />} />
            <Route path="/register" element={<CustomerRegisterForm />} />
            <Route path="/customer-details" element={<CustomerDetailsPage />} />
            <Route path="/customer-login" element={<SignInCustomer />} />
            <Route path="/customer-home" element={<CustomerHomePage />} />
            <Route path="/customer-feedback" element={<CustomerFeedbackPage />} />

            {/* Users */}
            <Route path="/user-register" element={<RegisterUser />} />
            <Route path="/user-details" element={<UserDetailsPage />} />
            <Route path="/user-login" element={<SignInUser />} />

            {/* Products */}
            <Route path="/products" element={<ProductPage />} />

            {/* Orders */}
            <Route path="/orders" element={<OrderPage />} />

            {/* Suppliers */}
            <Route path="/suppliers" element={<SupplierPage />} />

             {/* Deleveries */}
            <Route path="/deliveries" element={<DeliveryPage />} />

            <Route path="/" element={<HomePage />} />
              
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
