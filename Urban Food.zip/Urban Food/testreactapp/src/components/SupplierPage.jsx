import React, { useState, useEffect } from 'react';
import { getAllSuppliers, getSupplierById, addSupplier, updateSupplier, deleteSupplier } from '../services/supplierService';
import './SupplierPage.css';

const SupplierPage = () => {
    const [suppliers, setSuppliers] = useState([]);
    const [searchId, setSearchId] = useState('');
    const [newSupplier, setNewSupplier] = useState({ name: '', contactNumber: '', email: '', address: '' });
    const [editSupplier, setEditSupplier] = useState(null);

    useEffect(() => {
        fetchSuppliers();
    }, []);

    const fetchSuppliers = async () => {
        try {
            const res = await getAllSuppliers();
            setSuppliers(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleSearch = async () => {
        if (searchId.trim() === '') {
            fetchSuppliers();
            return;
        }
        try {
            const res = await getSupplierById(searchId);
            setSuppliers([res.data]);
        } catch (err) {
            console.error('Supplier not found');
            setSuppliers([]);
        }
    };

    const handleAddSupplier = async () => {
        try {
            await addSupplier(newSupplier);
            setNewSupplier({ name: '', contactNumber: '', email: '', address: '' });
            fetchSuppliers();
        } catch (err) {
            console.error(err);
        }
    };

    const handleUpdateSupplier = async () => {
        try {
            await updateSupplier(editSupplier.id, editSupplier);
            setEditSupplier(null);
            fetchSuppliers();
        } catch (err) {
            console.error(err);
        }
    };

    const handleDeleteSupplier = async (id) => {
        try {
            await deleteSupplier(id);
            fetchSuppliers();
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="supplier-page">
            <h1>🚚 Supplier Management</h1>

            <div className="search-bar">
                <input 
                    type="text" 
                    placeholder="Search by Supplier ID" 
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                />
                <button onClick={handleSearch}>Search</button>
            </div>

            <div className="add-supplier">
                <h2>Add New Supplier</h2>
                <input type="text" placeholder="Name" value={newSupplier.name} onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })} />
                <input type="text" placeholder="Contact Number" value={newSupplier.contactNumber} onChange={(e) => setNewSupplier({ ...newSupplier, contactNumber: e.target.value })} />
                <input type="email" placeholder="Email" value={newSupplier.email} onChange={(e) => setNewSupplier({ ...newSupplier, email: e.target.value })} />
                <input type="text" placeholder="Address" value={newSupplier.address} onChange={(e) => setNewSupplier({ ...newSupplier, address: e.target.value })} />
                <button onClick={handleAddSupplier}>Add Supplier</button>
            </div>

            <div className="supplier-list">
                {suppliers.map((supplier) => (
                    <div key={supplier.id} className="supplier-card">
                        <h3>{supplier.name}</h3>
                        <p>Contact: {supplier.contactNumber}</p>
                        <p>Email: {supplier.email}</p>
                        <p>Address: {supplier.address}</p>
                        <div className="card-buttons">
                            <button onClick={() => setEditSupplier(supplier)}>Edit</button>
                            <button onClick={() => handleDeleteSupplier(supplier.id)}>Delete</button>
                        </div>
                    </div>
                ))}
            </div>

            {editSupplier && (
                <div className="edit-modal">
                    <h2>Edit Supplier</h2>
                    <input type="text" value={editSupplier.name} onChange={(e) => setEditSupplier({ ...editSupplier, name: e.target.value })} />
                    <input type="text" value={editSupplier.contactNumber} onChange={(e) => setEditSupplier({ ...editSupplier, contactNumber: e.target.value })} />
                    <input type="email" value={editSupplier.email} onChange={(e) => setEditSupplier({ ...editSupplier, email: e.target.value })} />
                    <input type="text" value={editSupplier.address} onChange={(e) => setEditSupplier({ ...editSupplier, address: e.target.value })} />
                    <div className="modal-buttons">
                        <button onClick={handleUpdateSupplier}>Update</button>
                        <button onClick={() => setEditSupplier(null)}>Cancel</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default SupplierPage;
