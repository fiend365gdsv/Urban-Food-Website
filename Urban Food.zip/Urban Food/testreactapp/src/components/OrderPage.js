// src/components/OrderPage.js

import React, { useState, useEffect } from 'react';
import { getAllOrders, getOrderById, updateOrder, deleteOrder } from '../services/orderService';
import './OrderPage.css';

const OrderPage = () => {
    const [searchId, setSearchId] = useState('');
    const [orders, setOrders] = useState([]);
    const [editOrder, setEditOrder] = useState(null);

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const res = await getAllOrders();
            setOrders(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleSearch = async () => {
        if (searchId.trim() === '') {
            fetchOrders();
            return;
        }
        try {
            const res = await getOrderById(searchId);
            setOrders([res.data]);
        } catch (err) {
            console.error('Order not found');
            setOrders([]);
        }
    };

    const handleUpdateOrder = async () => {
        try {
            await updateOrder(editOrder.id, editOrder.productId, editOrder.quantity);
            setEditOrder(null);
            fetchOrders();
        } catch (err) {
            console.error(err);
        }
    };

    const handleDeleteOrder = async (id) => {
        try {
            await deleteOrder(id);
            fetchOrders();
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="order-page">
            <h1>🛒 Order Management</h1>

            <div className="search-bar">
                <input 
                    type="text" 
                    placeholder="Search by Order ID" 
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                />
                <button onClick={handleSearch}>Search</button>
            </div>

            <div className="order-list">
                {orders.map((order) => (
                    <div key={order.id} className="order-card">
                        <h3>Order ID: {order.id}</h3>
                        <p>Product: {order.productName}</p>
                        <p>Quantity: {order.quantity}</p>
                        <p>Total Price: Rs.{order.totalPrice}</p>
                        <div className="card-buttons">
                            <button onClick={() => setEditOrder(order)}>Edit</button>
                            <button onClick={() => handleDeleteOrder(order.id)}>Delete</button>
                        </div>
                    </div>
                ))}
            </div>

            {editOrder && (
                <div className="edit-modal">
                    <h2>Edit Order</h2>
                    <input
                        type="text"
                        value={editOrder.productId}
                        onChange={(e) => setEditOrder({ ...editOrder, productId: e.target.value })}
                        placeholder="Product ID"
                    />
                    <input
                        type="number"
                        value={editOrder.quantity}
                        onChange={(e) => setEditOrder({ ...editOrder, quantity: e.target.value })}
                        placeholder="Quantity"
                    />
                    <div className="modal-buttons">
                        <button onClick={handleUpdateOrder}>Update</button>
                        <button onClick={() => setEditOrder(null)}>Cancel</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OrderPage;
