import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // ✅ Import useNavigate
import { getAllProducts, getProductById, addProduct, updateProduct, deleteProduct } from '../services/productService';
import './ProductPage.css';

const ProductPage = () => {
    const [products, setProducts] = useState([]);
    const [searchId, setSearchId] = useState('');
    const [newProduct, setNewProduct] = useState({ productName: '', category: '', price: '', stock: '' });
    const [editProduct, setEditProduct] = useState(null);

    const navigate = useNavigate(); // ✅ Initialize navigate

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const res = await getAllProducts();
            setProducts(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleSearch = async () => {
        if (searchId.trim() === '') {
            fetchProducts();
            return;
        }
        try {
            const res = await getProductById(searchId);
            setProducts([res.data]);
        } catch (err) {
            console.error('Product not found');
            setProducts([]);
        }
    };

    const handleAddProduct = async () => {
        try {
            await addProduct(newProduct);
            setNewProduct({ productName: '', category: '', price: '', stock: '' });
            fetchProducts();
        } catch (err) {
            console.error(err);
        }
    };

    const handleUpdateProduct = async () => {
        try {
            await updateProduct(editProduct.id, editProduct);
            setEditProduct(null);
            fetchProducts();
        } catch (err) {
            console.error(err);
        }
    };

    const handleDeleteProduct = async (id) => {
        try {
            await deleteProduct(id);
            fetchProducts();
        } catch (err) {
            console.error(err);
        }
    };

    const goToUsersPage = () => {
        navigate('/user-details'); // ✅ Navigate to /user-details
    };

    const goToDeliveriesPage = () => {
        navigate('/deliveries'); // ✅ Navigate to /deliveries
    };

    const goToSuppliersPage = () => {
        navigate('/suppliers'); // ✅ Navigate to /suppliers
    };

    const goToOrdersPage = () => {
        navigate('/orders'); // ✅ Navigate to /orders
    };
    const goToCustomersPage = () => {
        navigate('/customer-details'); // ✅ Navigate to /customer-details
    };

    return (
        <div className="product-page">
            <div className="top-bar">
                <h1>🛒 Product Management</h1>
                {/* ✅ Users Button */}
                <button onClick={goToUsersPage} className="users-button">
                    Users
                </button>
                {/* ✅ Delivery Button */}
                <button onClick={goToDeliveriesPage} className="delivery-button">
                    Deliveries
                </button>
                {/* ✅ Supplier Button */}
                <button onClick={goToSuppliersPage} className="supplier-button">
                    Suppliers
                </button>
                {/* ✅ Orders Button */}
                <button onClick={goToOrdersPage} className="orders-button">
                    Orders
                </button>
                {/* ✅ Customers Button */}
                <button onClick={goToCustomersPage} className="customers-button">
                     Customers
                </button>

            </div>

            <div className="search-bar">
                <input 
                    type="text" 
                    placeholder="Search by Product ID" 
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                />
                <button onClick={handleSearch}>Search</button>
            </div>

            <div className="add-product">
                <h2>Add New Product</h2>
                <input type="text" placeholder="Product Name" value={newProduct.productName} onChange={(e) => setNewProduct({ ...newProduct, productName: e.target.value })} />
                <input type="text" placeholder="Category" value={newProduct.category} onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })} />
                <input type="number" placeholder="Price" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} />
                <input type="text" placeholder="Stock" value={newProduct.stock} onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })} />
                <button onClick={handleAddProduct}>Add Product</button>
            </div>

            <div className="product-list">
                {products.map((product) => (
                    <div key={product.id} className="product-card">
                        <h3>{product.productName}</h3>
                        <p>Category: {product.category}</p>
                        <p>Price: Rs.{product.price}</p>
                        <p>Stock: {product.stock}</p>
                        <div className="card-buttons">
                            <button onClick={() => setEditProduct(product)}>Edit</button>
                            <button onClick={() => handleDeleteProduct(product.id)}>Delete</button>
                        </div>
                    </div>
                ))}
            </div>

            {editProduct && (
                <div className="edit-modal">
                    <h2>Edit Product</h2>
                    <input type="text" value={editProduct.productName} onChange={(e) => setEditProduct({ ...editProduct, productName: e.target.value })} />
                    <input type="text" value={editProduct.category} onChange={(e) => setEditProduct({ ...editProduct, category: e.target.value })} />
                    <input type="number" value={editProduct.price} onChange={(e) => setEditProduct({ ...editProduct, price: e.target.value })} />
                    <input type="text" value={editProduct.stock} onChange={(e) => setEditProduct({ ...editProduct, stock: e.target.value })} />
                    <div className="modal-buttons">
                        <button onClick={handleUpdateProduct}>Update</button>
                        <button onClick={() => setEditProduct(null)}>Cancel</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProductPage;

