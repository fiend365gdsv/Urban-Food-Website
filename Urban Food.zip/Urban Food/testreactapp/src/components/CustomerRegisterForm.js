import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation

const CustomerRegisterForm = () => {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    address: '',
    phone: ''
  });

  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // Initialize useNavigate

  const handleChange = (e) => {
    setFormData({ 
      ...formData, 
      [e.target.name]: e.target.value 
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8083/customers/register', formData);
      setMessage('Customer registered successfully!');
      console.log(response.data);

      // After successful registration, navigate to /customer-home
      setTimeout(() => {
        navigate('/customer-home', { state: { customer: response.data } }); // Passing the customer data to customer-home
      }, 1000); // Optional delay for smooth navigation

      // Clear the form after successful registration
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        password: '',
        address: '',
        phone: ''
      });
    } catch (error) {
      console.error('Registration failed:', error);
      setMessage('Registration failed.');
    }
  };

  return (
    <div className="register-container">
      <h2 style={{ color: 'white', textAlign: 'center' }}>Register Customer</h2>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          name="first_name" 
          placeholder="First Name" 
          onChange={handleChange} 
          value={formData.first_name} 
          required 
        />
        <input 
          type="text" 
          name="last_name" 
          placeholder="Last Name" 
          onChange={handleChange} 
          value={formData.last_name} 
          required 
        />
        <input 
          type="email" 
          name="email" 
          placeholder="Email" 
          onChange={handleChange} 
          value={formData.email} 
          required 
        />
        <input 
          type="password" 
          name="password" 
          placeholder="Password" 
          onChange={handleChange} 
          value={formData.password} 
          required 
        />
        <input 
          type="text" 
          name="phone" 
          placeholder="Phone" 
          onChange={handleChange} 
          value={formData.phone} 
          required 
        />
        <input 
          type="text" 
          name="address" 
          placeholder="Address" 
          onChange={handleChange} 
          value={formData.address} 
          required 
        />
        <button type="submit">Register</button>
      </form>
      {message && (
        <p className={`message ${message.includes('success') ? 'success' : 'error'}`}>
          {message}
        </p>
      )}
    </div>
  );
};

export default CustomerRegisterForm;
