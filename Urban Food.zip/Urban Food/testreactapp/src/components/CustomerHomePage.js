import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import axios from 'axios';
import './CustomerHomePage.css';

function CustomerHomePage() {
  const location = useLocation();
  const user = location.state?.user;  // Access the user passed via the Link

  const [products, setProducts] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchProducts();
    fetchOrders();
  }, []);

  // Fetch all products
  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:8081/products/all');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  // Fetch all orders
  const fetchOrders = async () => {
    try {
      const response = await axios.get('http://localhost:8080/orders/all');
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  // Handle quantity change for the product
  const handleQuantityChange = (productId, value) => {
    setQuantities({
      ...quantities,
      [productId]: value,
    });
  };

  // Place an order
  const placeOrder = async (productId) => {
    const quantity = quantities[productId] || 1;
    try {
      await axios.post('http://localhost:8080/orders/place', null, {
        params: {
          productId,
          quantity,
        },
      });
      setSuccessMessage('Order placed successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
      fetchOrders();
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order.');
    }
  };

  // Delete an order by ID
  const deleteOrder = async (orderId) => {
    try {
      await axios.delete(`http://localhost:8080/orders/${orderId}`);
      setSuccessMessage('Order deleted successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
      fetchOrders();
    } catch (error) {
      console.error('Error deleting order:', error);
      alert('Failed to delete order.');
    }
  };

  // Update an order
  const updateOrder = async (orderId, productId, quantity) => {
    try {
      await axios.put(`http://localhost:8080/orders/${orderId}`, null, {
        params: {
          productId,
          quantity,
        },
      });
      setSuccessMessage('Order updated successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
      fetchOrders();
    } catch (error) {
      console.error('Error updating order:', error);
      alert('Failed to update order.');
    }
  };

  return (
    <div className="customer-home-container">
      <h2>Welcome, {user?.userName || 'Customer'}!</h2>

      <h2>Available Products</h2>
      <div className="products-grid">
        {products.map((product) => (
          <div className="product-card" key={product.id}>
            <h4>{product.productName}</h4>
            <p><strong>Category:</strong> {product.category}</p>
            <p><strong>Price:</strong> Rs.{product.price}</p>
            <p><strong>Stock:</strong> {product.stock}</p>
            <input
              type="number"
              min="1"
              max={product.stock}
              placeholder="Quantity"
              value={quantities[product.id] || ''}
              onChange={(e) => handleQuantityChange(product.id, e.target.value)}
              className="quantity-input"
            />
            <button onClick={() => placeOrder(product.id)} className="order-button">
              Place Order
            </button>
          </div>
        ))}
      </div>

      {/* Display orders */}
      <h2>Your Orders</h2>
      <div className="orders-list">
        {orders.map((order) => (
          <div className="order-card" key={order.id}>
            <p><strong>Product Name:</strong> {order.productName}</p>
            <p><strong>Quantity:</strong> 
              <input
                type="number"
                value={quantities[order.id] || order.quantity}
                onChange={(e) => handleQuantityChange(order.id, e.target.value)}
                min="1"
                className="quantity-input"
              />
            </p>
            <p><strong>Status:</strong> {order.status}</p>
            <div className="order-actions">
              <button onClick={() => updateOrder(order.id, order.productId, quantities[order.id] || order.quantity)} className="update-button">
                Update Order
              </button>
              <button onClick={() => deleteOrder(order.id)} className="delete-button">
                Delete Order
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Feedback Button */}
      <div className="feedback-section">
        <Link to={{ pathname: '/customer-feedback', state: { user } }}>
          <button className="feedback-button">Give Feedback</button>
        </Link>
      </div>

      {/* Display the success message */}
      {successMessage && (
        <div className="success-popup">
          <p>{successMessage}</p>
        </div>
      )}
    </div>
  );
}

export default CustomerHomePage;
