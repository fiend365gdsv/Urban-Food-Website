import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './UserDetailsPage.css';

const UserDetailsPage = () => {
  const [users, setUsers] = useState([]);
  const [searchId, setSearchId] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [message, setMessage] = useState('');

  // Load all users
  useEffect(() => {
    axios.get('http://localhost:8084/users/all')
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  }, []);

  const handleSearch = () => {
    axios.get(`http://localhost:8084/users/${searchId}`)
      .then(res => setSelectedUser(res.data))
      .catch(err => {
        console.error(err);
        setMessage('User not found.');
      });
  };

  const handleUpdate = async () => {
    try {
      await axios.put(`http://localhost:8084/users/${selectedUser.id}`, selectedUser);
      setMessage('User updated successfully!');
    } catch (error) {
      console.error(error);
      setMessage('Update failed.');
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:8084/users/${selectedUser.id}`);
      setMessage('User deleted successfully!');
      setSelectedUser(null);
    } catch (error) {
      console.error(error);
      setMessage('Delete failed.');
    }
  };

  const handleInputChange = (e) => {
    setSelectedUser({ ...selectedUser, [e.target.name]: e.target.value });
  };

  return (
    <div className="user-details-container">
      <div className="search-box">
        <input
          type="text"
          placeholder="Search User by ID"
          value={searchId}
          onChange={(e) => setSearchId(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
      </div>

      {selectedUser && (
        <div className="selected-user-form">
          <h3>Edit User</h3>
          {["userName", "role", "email", "password", "phone", "address"].map(field => (
            <input
              key={field}
              type="text"
              name={field}
              placeholder={field}
              value={selectedUser[field] || ''}
              onChange={handleInputChange}
            />
          ))}
          <div className="btn-group">
            <button onClick={handleUpdate}>Update</button>
            <button onClick={handleDelete}>Delete</button>
          </div>
        </div>
      )}

      <div className="all-users">
        <h3>All Users</h3>
        <ul>
          {users.map(user => (
            <li key={user.id}>
              {user.id}-{user.email}-{user.userName}
            </li>
          ))}
        </ul>
      </div>

      {message && <p className="message">{message}</p>}
    </div>
  );
};

export default UserDetailsPage;
