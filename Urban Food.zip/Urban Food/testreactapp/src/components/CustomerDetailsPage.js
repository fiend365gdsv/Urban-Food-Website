import React, { useState } from 'react';
import axios from 'axios';
import bgImage from '../assets/wongdhen-cafe-delhi-imt6hknmm8.avif'; // Adjust path as needed

const CustomerDetailsPage = () => {
  const [id, setCustomerId] = useState('');
  const [customer, setCustomer] = useState(null);
  const [message, setMessage] = useState('');

  const handleSearch = async () => {
    try {
      const response = await axios.get(`http://localhost:8083/customers/${id}`);
      setCustomer(response.data);
      setMessage('');
    } catch (error) {
      setCustomer(null);
      setMessage('Customer not found.');
    }
  };

  const handleChange = (e) => {
    setCustomer({
      ...customer,
      [e.target.name]: e.target.value
    });
  };

  const handleUpdate = async () => {
    try {
      await axios.put(`http://localhost:8083/customers/${id}`, customer);
      setMessage('Customer updated successfully!');
    } catch (error) {
      setMessage('Update failed.');
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:8083/customers/${id}`);
      setCustomer(null);
      setCustomerId('');
      setMessage('Customer deleted successfully!');
    } catch (error) {
      setMessage('Delete failed.');
    }
  };

  return (
    <div
      className="details-container"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh',
        padding: '2rem',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <div
        className="form-container"
        style={{
          background: 'rgba(0, 0, 0, 0.5)', // Transparent black overlay
          padding: '2rem',
          borderRadius: '8px',
          width: '100%',
          maxWidth: '500px',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
          color: 'white',
        }}
      >
        <h2 style={{ textAlign: 'center', marginBottom: '1rem' }}>Search / Update / Delete Customer</h2>

        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center', marginBottom: '1rem' }}>
          <input 
            type="text" 
            placeholder="Enter Customer ID" 
            value={id}
            onChange={(e) => setCustomerId(e.target.value)}
            style={{
              padding: '10px',
              width: '70%',
              borderRadius: '4px',
              border: '1px solid #ccc',
            }}
          />
          <button
            type="button"
            onClick={handleSearch}
            style={{
              padding: '10px 15px',
              backgroundColor: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            Search
          </button>
        </div>

        {customer && (
          <form onSubmit={(e) => e.preventDefault()} className="customer-form">
            <input
              type="text"
              name="first_name"
              value={customer.first_name}
              onChange={handleChange}
              placeholder="First Name"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <input
              type="text"
              name="last_name"
              value={customer.last_name}
              onChange={handleChange}
              placeholder="Last Name"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <input
              type="email"
              name="email"
              value={customer.email}
              onChange={handleChange}
              placeholder="Email"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <input
              type="password"
              name="password"
              value={customer.password}
              onChange={handleChange}
              placeholder="Password"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <input
              type="text"
              name="phone"
              value={customer.phone}
              onChange={handleChange}
              placeholder="Phone"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <input
              type="text"
              name="address"
              value={customer.address}
              onChange={handleChange}
              placeholder="Address"
              style={{ width: '100%', padding: '10px', margin: '10px 0', borderRadius: '4px', border: '1px solid #ccc' }}
            />

            <div style={{ display: 'flex', justifyContent: 'space-between', gap: '10px' }}>
              <button
                type="button"
                onClick={handleUpdate}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#28a745',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                Update
              </button>
              <button
                type="button"
                onClick={handleDelete}
                className="delete-button"
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#dc3545',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                Delete
              </button>
            </div>
          </form>
        )}

        {message && (
          <p className={`message ${message.includes('success') ? 'success' : 'error'}`} style={{ marginTop: '1rem', fontWeight: 'bold' }}>
            {message}
          </p>
        )}
      </div>
    </div>
  );
};

export default CustomerDetailsPage;
