import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import navigate
import './UserRegister.css';

const SignInCustomer = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // useNavigate hook

  const handleChange = (e) => {
    setFormData({ 
      ...formData, 
      [e.target.name]: e.target.value 
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.get('http://localhost:8083/customers/all');
      const users = response.data;

      const user = users.find(u => u.email === formData.email && u.password === formData.password);

      if (user) {
        setMessage(`Welcome back, ${user.userName}!`);
        // Redirect after 1 second
        setTimeout(() => {
          navigate('/customer-home', { state: { user } }); // Passing user object to customer-home
        }, 1000);
      } else {
        setMessage('Invalid email or password.');
      }
    } catch (error) {
      console.error('Sign In failed:', error);
      setMessage('Sign In failed.');
    }
  };

  const handleSignUp = () => {
    navigate('/customer-register'); // Navigate to the customer-register page
  };

  return (
    <div className="user-register-container">
      <h2>Sign In</h2>
      <form onSubmit={handleSubmit}>
        <input 
          type="email" 
          name="email" 
          placeholder="Email" 
          onChange={handleChange} 
          value={formData.email} 
          required 
        />
        <input 
          type="password" 
          name="password" 
          placeholder="Password" 
          onChange={handleChange} 
          value={formData.password} 
          required 
        />
        <button type="submit">Sign In</button>
      </form>

      {/* Sign Up Button */}
      <button type="button" className="signup-button" onClick={handleSignUp}>
        Sign Up
      </button>

      {message && (
        <p className={`message ${message.includes('Welcome') ? 'success' : 'error'}`}>
          {message}
        </p>
      )}
    </div>
  );
};

export default SignInCustomer;
