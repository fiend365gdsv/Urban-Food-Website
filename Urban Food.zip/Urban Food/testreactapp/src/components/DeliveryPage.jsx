import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './DeliveryPage.css'; // Import the new CSS

const BASE_URL = 'http://localhost:8089/deliveries'; 

const DeliveryPage = () => {
  const [deliveries, setDeliveries] = useState([]);
  const [search, setSearch] = useState('');
  const [newDelivery, setNewDelivery] = useState({
    customerId: '',
    orderId: '',
    deliveryStatus: 'pending',
  });
  const [editDelivery, setEditDelivery] = useState(null);

  useEffect(() => {
    fetchDeliveries();
  }, []);

  const fetchDeliveries = async () => {
    const response = await axios.get(`${BASE_URL}/all`);
    setDeliveries(response.data);
  };

  const handleAddDelivery = async () => {
    await axios.post(`${BASE_URL}/add`, newDelivery);
    fetchDeliveries();
    setNewDelivery({ customerId: '', orderId: '', deliveryStatus: 'pending' });
  };

  const handleUpdateDelivery = async () => {
    await axios.put(`${BASE_URL}/${editDelivery.deliveryId}`, {
      customerId: editDelivery.customerId,
      orderId: editDelivery.orderId,
      deliveryStatus: editDelivery.deliveryStatus,
    });
    setEditDelivery(null);
    fetchDeliveries();
  };

  const handleDeleteDelivery = async (id) => {
    try {
      console.log(`Sending DELETE request to: ${BASE_URL}/${id}`);
      const response = await axios.delete(`${BASE_URL}/${id}`);
      console.log('Response:', response);
      fetchDeliveries();
    } catch (error) {
      console.error('Error deleting delivery:', error.response || error);
    }
  };
  

  const filteredDeliveries = deliveries.filter(d =>
    d.customerId.toString().includes(search) ||
    d.deliveryId.toString().includes(search)
  );

  return (
    <div className="delivery-page">
      <h1 className="title">Delivery Management</h1>

      {/* Search */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by Delivery ID or Customer ID..."
          className="input"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Delivery Table */}
      <div className="table-container">
        <table className="delivery-table">
          <thead>
            <tr>
              <th>Delivery ID</th>
              <th>Customer ID</th>
              <th>Order ID</th>
              <th>Address</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredDeliveries.map((delivery) => (
              <tr key={delivery.deliveryId}>
                <td>{delivery.deliveryId}</td>
                <td>{delivery.customerId}</td>
                <td>{delivery.orderId}</td>
                <td>{delivery.address}</td>
                <td>{delivery.deliveryStatus}</td>
                <td>
                  <button
                    className="btn edit-btn"
                    onClick={() => setEditDelivery(delivery)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn delete-btn"
                    onClick={() => handleDeleteDelivery(delivery.deliveryId)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Delivery Form */}
      <div className="form-container">
        <h2 className="subtitle">Add New Delivery</h2>
        <input
          type="text"
          placeholder="Customer ID"
          className="input"
          value={newDelivery.customerId}
          onChange={(e) => setNewDelivery({ ...newDelivery, customerId: e.target.value })}
        />
        <input
          type="text"
          placeholder="Order ID"
          className="input"
          value={newDelivery.orderId}
          onChange={(e) => setNewDelivery({ ...newDelivery, orderId: e.target.value })}
        />
        <select
          className="input"
          value={newDelivery.deliveryStatus}
          onChange={(e) => setNewDelivery({ ...newDelivery, deliveryStatus: e.target.value })}
        >
          <option value="pending">Pending</option>
          <option value="shipped">Shipped</option>
          <option value="delivered">Delivered</option>
        </select>
        <button
          className="btn primary-btn"
          onClick={handleAddDelivery}
        >
          Add Delivery
        </button>
      </div>

      {/* Edit Delivery Modal */}
      {editDelivery && (
        <div className="modal-backdrop">
          <div className="modal">
            <h2 className="subtitle">Edit Delivery</h2>
            <select
              className="input"
              value={editDelivery.deliveryStatus}
              onChange={(e) => setEditDelivery({ ...editDelivery, deliveryStatus: e.target.value })}
            >
              <option value="pending">Pending</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
            </select>
            <div className="modal-actions">
              <button
                className="btn save-btn"
                onClick={handleUpdateDelivery}
              >
                Save
              </button>
              <button
                className="btn cancel-btn"
                onClick={() => setEditDelivery(null)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DeliveryPage;
