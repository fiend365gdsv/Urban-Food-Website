import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './UserRegister.css';

const RegisterUser = () => {
  const [formData, setFormData] = useState({
    userName: '',
    role: '',
    email: '',
    password: '',
    address: '',
    phone: ''
  });

  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // Initialize navigate

  const handleChange = (e) => {
    setFormData({ 
      ...formData, 
      [e.target.name]: e.target.value 
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8084/users/register', formData);
      setMessage('User registered successfully!');
      console.log(response.data);

      // After successful registration, navigate to /customer-home
      setTimeout(() => {
        navigate('/products', { state: { user: response.data } }); // Passing the user data to customer-home
      }, 1000);

      // Clear form after successful registration
      setFormData({
        userName: '',
        role: '',
        email: '',
        password: '',
        address: '',
        phone: ''
      });
    } catch (error) {
      console.error('Registration failed:', error);
      setMessage('Registration failed.');
    }
  };

  return (
    <div className="user-register-container">
      <h2>Register User</h2>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          name="userName" 
          placeholder="User Name" 
          onChange={handleChange} 
          value={formData.userName} 
          required 
        />
        <input 
          type="text" 
          name="role" 
          placeholder="Role" 
          onChange={handleChange} 
          value={formData.role} 
          required 
        />
        <input 
          type="email" 
          name="email" 
          placeholder="Email" 
          onChange={handleChange} 
          value={formData.email} 
          required 
        />
        <input 
          type="password" 
          name="password" 
          placeholder="Password" 
          onChange={handleChange} 
          value={formData.password} 
          required 
        />
        <input 
          type="text" 
          name="phone" 
          placeholder="Phone" 
          onChange={handleChange} 
          value={formData.phone} 
          required 
        />
        <input 
          type="text" 
          name="address" 
          placeholder="Address" 
          onChange={handleChange} 
          value={formData.address} 
          required 
        />
        <button type="submit">Register</button>
      </form>
      {message && (
        <p className={`message ${message.includes('success') ? 'success' : 'error'}`}>
          {message}
        </p>
      )}
    </div>
  );
};

export default RegisterUser;
