import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './CustomerFeedbackPage.css';

function CustomerFeedbackPage() {
  const location = useLocation();
  const user = location.state?.user; // Accessing user from location state

  // Declare hooks
  const [feedbacks, setFeedbacks] = useState([]);
  const [newFeedback, setNewFeedback] = useState('');
  const [newFeedbackId, setNewFeedbackId] = useState('');
  const [newRating, setNewRating] = useState(5); // Default rating
  const [editingFeedbackId, setEditingFeedbackId] = useState(null);
  const [editingContent, setEditingContent] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Fetch feedbacks for the user
  const fetchFeedbacks = useCallback(async () => {
    if (!user) return; // Ensure user exists before fetching
    try {
      const response = await axios.get(`http://localhost:8083/feedbacks/customer/${user.id}`);
      setFeedbacks(response.data);
    } catch (error) {
      console.error('Error fetching feedbacks:', error);
    }
  }, [user]);

  useEffect(() => {
    fetchFeedbacks();
  }, [fetchFeedbacks]);

  // If the user is not available, show an error message
  if (!user) {
    return (
      <div className="error-message">
        <p>Error: User not found. Please log in again.</p>
      </div>
    );
  }

  // Add feedback function
  const addFeedback = async () => {
    if (newFeedback.trim() === '' || newFeedbackId.trim() === '') return; // Avoid submitting empty feedback or id
    try {
      const feedbackData = {
        id: newFeedbackId, // Manually input the feedback ID
        customerId: user.id, // Pass user ID
        feedbackText: newFeedback,
        rating: newRating, // User input rating
      };
      console.log('Sending Feedback:', feedbackData);

      await axios.post('http://localhost:8083/feedbacks/add', feedbackData);

      setSuccessMessage('Feedback added successfully!');
      setNewFeedback('');
      setNewFeedbackId('');
      fetchFeedbacks(); // Refresh feedback list after adding feedback
      setTimeout(() => setSuccessMessage(''), 3000); // Clear success message after 3 seconds
    } catch (error) {
      console.error('Error adding feedback:', error);
      alert('Failed to add feedback.');
    }
  };

  // Delete feedback function
  const deleteFeedback = async (id) => {
    try {
      await axios.delete(`http://localhost:8083/feedbacks/${id}`);
      setSuccessMessage('Feedback deleted successfully!');
      fetchFeedbacks(); // Refresh feedback list after deletion
      setTimeout(() => setSuccessMessage(''), 3000); // Clear success message after 3 seconds
    } catch (error) {
      console.error('Error deleting feedback:', error);
      alert('Failed to delete feedback.');
    }
  };

  // Start editing feedback
  const startEditing = (id, content) => {
    setEditingFeedbackId(id);
    setEditingContent(content);
  };

  // Update feedback function
  const updateFeedback = async () => {
    try {
      await axios.put(`http://localhost:8083/feedbacks/update/${editingFeedbackId}`, {
        feedbackText: editingContent,
        rating: newRating, // Assuming rating remains unchanged
      });
      setSuccessMessage('Feedback updated successfully!');
      setEditingFeedbackId(null);
      setEditingContent('');
      fetchFeedbacks(); // Refresh feedback list after update
      setTimeout(() => setSuccessMessage(''), 3000); // Clear success message after 3 seconds
    } catch (error) {
      console.error('Error updating feedback:', error);
      alert('Failed to update feedback.');
    }
  };

  return (
    <div className="customer-feedback-container">
      <h2>Feedback Section</h2>

      {/* Add Feedback */}
      <div className="add-feedback-section">
        <div className="input-group">
          <input
            type="text"
            placeholder="Enter Feedback ID"
            value={newFeedbackId}
            onChange={(e) => setNewFeedbackId(e.target.value)}
            className="feedback-id-input"
          />
        </div>
        <div className="input-group">
          <textarea
            value={newFeedback}
            onChange={(e) => setNewFeedback(e.target.value)}
            placeholder="Write your feedback..."
            rows="4"
            className="feedback-textarea"
          ></textarea>
        </div>
        <div className="input-group">
          <label>Rating:</label>
          <select value={newRating} onChange={(e) => setNewRating(Number(e.target.value))}>
            <option value={1}>1</option>
            <option value={2}>2</option>
            <option value={3}>3</option>
            <option value={4}>4</option>
            <option value={5}>5</option>
          </select>
        </div>
        <button onClick={addFeedback} className="add-feedback-button">
          Submit Feedback
        </button>
      </div>

      {/* List of Feedbacks */}
      <div className="feedbacks-list">
        {feedbacks.map((fb) => (
          <div className="feedback-card" key={fb.id}>
            {editingFeedbackId === fb.id ? (
              <>
                <textarea
                  value={editingContent}
                  onChange={(e) => setEditingContent(e.target.value)}
                  rows="3"
                  className="edit-textarea"
                />
                <div className="feedback-actions">
                  <button onClick={updateFeedback} className="update-button">Save</button>
                  <button onClick={() => setEditingFeedbackId(null)} className="cancel-button">Cancel</button>
                </div>
              </>
            ) : (
              <>
                <p>{fb.feedbackText}</p>
                <div className="feedback-actions">
                  <button onClick={() => startEditing(fb.id, fb.feedbackText)} className="update-button">Edit</button>
                  <button onClick={() => deleteFeedback(fb.id)} className="delete-button">Delete</button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Success Popup */}
      {successMessage && (
        <div className="success-popup">
          <p>{successMessage}</p>
        </div>
      )}
    </div>
  );
}

export default CustomerFeedbackPage;
