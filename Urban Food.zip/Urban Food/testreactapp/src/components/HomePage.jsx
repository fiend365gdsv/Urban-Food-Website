import React, { useState } from 'react';
import './HomePage.css';
import { useNavigate } from 'react-router-dom'; 

const HomePage = () => {
  const navigate = useNavigate();
  const [showOptions, setShowOptions] = useState(false); // 🆕 state

  const handleSignIn = () => {
    setShowOptions(true); // 🆕 show options
  };

  const handleOptionClick = (type) => {
    if (type === 'customer') {
      navigate('/customer-login');
    } else if (type === 'user') {
      navigate('/user-login');
    }
    setShowOptions(false); // hide after selecting
  };

  return (
    <div className="home-container">

      {/* Header Section */}
      <header className="home-header">
        <div className="logo">UrbanFood</div>
        <nav>
          <a href="#">Home</a>
          <a href="#">Menu</a>
          <a href="#">About</a>
          <a href="#">Contact</a>
          <button className="signin-button" onClick={handleSignIn}>Sign In</button>
        </nav>
      </header>

      {/* 🆕 Sign In Options Modal */}
      {showOptions && (
        <div className="signin-options-overlay">
          <div className="signin-options">
            <h3>Select Login Type</h3>
            <button onClick={() => handleOptionClick('customer')}>Customer</button>
            <button onClick={() => handleOptionClick('user')}>User</button>
            <button onClick={() => setShowOptions(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="home-hero">
        <h1>Fresh Urban Flavors Delivered to You</h1>
        <button>Order Now</button>
      </section>

      {/* About Section */}
      <section className="home-about">
        <h2>About Urban Food</h2>
        <p>We deliver the best urban culinary experience right to your doorsteps. Fresh, fast, fabulous!</p>
      </section>

      {/* Popular Items Section */}
      <section className="home-popular-items">
        <h2>Popular Items</h2>
        <div className="items-container">
          <div className="item-card">
            <img src="https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=60" alt="Urban Burger" />
            <h3>Urban Burger</h3>
            <p>$8.99</p>
          </div>
          <div className="item-card">
            <img src="https://images.unsplash.com/photo-1572441710534-82f9c83b1b97?auto=format&fit=crop&w=800&q=60" alt="Fresh Salad" />
            <h3>Fresh Salad</h3>
            <p>$6.49</p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="home-testimonials">
        <h2>What Our Customers Say</h2>
        <p>"Amazing food and super quick delivery!" - John D.</p>
        <p>"The Urban Salad is my favorite! So fresh!" - Sarah L.</p>
      </section>

      {/* Newsletter Section */}
      <section className="home-newsletter">
        <h2>Stay Updated!</h2>
        <input type="email" placeholder="Enter your email" />
        <button>Subscribe</button>
      </section>

      {/* Footer Section */}
      <footer className="home-footer">
        <p>© 2025 UrbanFood. All rights reserved.</p>
      </footer>

    </div>
  );
};

export default HomePage;
