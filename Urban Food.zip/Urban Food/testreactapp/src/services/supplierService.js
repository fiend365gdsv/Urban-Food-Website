import axios from 'axios';

const BASE_URL = 'http://localhost:8085/suppliers'; 

export const getAllSuppliers = () => axios.get(`${BASE_URL}/all`);
export const getSupplierById = (id) => axios.get(`${BASE_URL}/${id}`);
export const addSupplier = (supplier) => axios.post(`${BASE_URL}/add`, supplier);
export const updateSupplier = (id, supplier) => axios.put(`${BASE_URL}/${id}`, supplier);
export const deleteSupplier = (id) => axios.delete(`${BASE_URL}/${id}`);
