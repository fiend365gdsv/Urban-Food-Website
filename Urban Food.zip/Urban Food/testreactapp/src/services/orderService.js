import axios from 'axios';

const BASE_URL = 'http://localhost:8080/orders'; 

export const getAllOrders = () => axios.get(`${BASE_URL}/all`);
export const getOrderById = (id) => axios.get(`${BASE_URL}/${id}`);
export const placeOrder = (productId, quantity) => axios.post(`${BASE_URL}/place?productId=${productId}&quantity=${quantity}`);
export const updateOrder = (id, productId, quantity) => axios.put(`${BASE_URL}/${id}?productId=${productId}&quantity=${quantity}`);
export const deleteOrder = (id) => axios.delete(`${BASE_URL}/${id}`);
