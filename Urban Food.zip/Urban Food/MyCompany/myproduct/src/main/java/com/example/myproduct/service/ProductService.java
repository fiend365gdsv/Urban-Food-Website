package com.example.myproduct.service;

import com.example.myproduct.dto.ProductDTO;
import com.example.myproduct.model.Product;
import oracle.jdbc.OracleTypes;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;



@Service
@Transactional
public class ProductService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ModelMapper modelMapper;

    public List<ProductDTO> getAllProducts() {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_all_products")
                .declareParameters(new SqlOutParameter("result_cursor", OracleTypes.CURSOR, new ColumnMapRowMapper()))
                .withoutProcedureColumnMetaDataAccess();

        Map<String, Object> result = jdbcCall.execute();

        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.get("result_cursor");

        List<ProductDTO> productDTOs = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            ProductDTO dto = new ProductDTO(
                    ((Number) row.get("ID")).longValue(),
                    (String) row.get("PRODUCT_NAME"),
                    (String) row.get("CATEGORY"),
                    ((Number) row.get("PRICE")).doubleValue(),
                    String.valueOf(row.get("STOCK"))
            );
            productDTOs.add(dto);
        }

        return productDTOs;
    }


    public ProductDTO getProductById(Long id) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_product_by_id")
                .declareParameters(
                        new SqlParameter("p_id", Types.NUMERIC),
                        new SqlOutParameter("result_cursor", OracleTypes.CURSOR, new ColumnMapRowMapper())
                )
                .withoutProcedureColumnMetaDataAccess();

        Map<String, Object> result = jdbcCall.execute(Map.of("p_id", id));

        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.get("result_cursor");

        if (rows == null || rows.isEmpty()) return null;

        Map<String, Object> row = rows.get(0);
        return new ProductDTO(
                ((Number) row.get("ID")).longValue(),
                (String) row.get("PRODUCT_NAME"),
                (String) row.get("CATEGORY"),
                ((Number) row.get("PRICE")).doubleValue(),
                String.valueOf(row.get("STOCK"))
        );
    }


    public void addProduct(ProductDTO productDTO) {
        Product product = modelMapper.map(productDTO, Product.class);

        String sql = "BEGIN add_products(?, ?, ?, ?); END;";
        jdbcTemplate.execute(sql, (CallableStatement cs) -> {
            cs.setString(1, product.getProductName());
            cs.setString(2, product.getCategory());
            cs.setDouble(3, product.getPrice());
            cs.setString(4, product.getStock());
            cs.execute();
            return null;
        });

    }

    public void updateProduct(Long id, ProductDTO productDTO) {
        productDTO.setId(id);
        Product product = modelMapper.map(productDTO, Product.class);

        String sql = "BEGIN update_products(?, ?, ?, ?, ?); END;";
        jdbcTemplate.execute(sql, (CallableStatement cs) -> {
            cs.setLong(1, product.getId());
            cs.setString(2, product.getProductName());
            cs.setString(3, product.getCategory());
            cs.setDouble(4, product.getPrice());
            cs.setString(5, product.getStock());
            cs.execute();
            return null;
        });
    }

    public void deleteProduct(Long id) {
        String sql = "BEGIN delete_products(?); END;";
        jdbcTemplate.execute(sql, (CallableStatement cs) -> {
            cs.setLong(1, id);
            cs.execute();
            return null;
        });
    }
}
