package com.example.myorder.controller;

import com.example.myorder.model.Orders;
import com.example.myorder.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/place")
    public void placeOrder(@RequestParam Long productId, @RequestParam int quantity) {
        orderService.addOrder(productId, quantity);
    }

    @GetMapping("/all")
    public List<Orders> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    public Orders getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id);
    }

    @PutMapping("/{id}")
    public void updateOrder(@PathVariable Long id, @RequestParam Long productId, @RequestParam int quantity) {
        orderService.updateOrder(id, productId, quantity);
    }

    @DeleteMapping("/{id}")
    public void deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
    }
}
