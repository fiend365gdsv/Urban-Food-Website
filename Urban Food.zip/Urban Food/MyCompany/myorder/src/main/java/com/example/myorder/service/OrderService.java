package com.example.myorder.service;

import com.example.myorder.client.ProductClient;
import com.example.myorder.dto2.ProductResponse;
import com.example.myorder.model.Orders;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final DataSource dataSource;
    private final ProductClient productClient;

    public void addOrder(Long productId, int quantity) {
        ProductResponse product = productClient.getProductById(productId);
        if (product.getStock() < quantity) {
            throw new RuntimeException("Not enough stock available");
        }

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call add_order(?, ?)}");
            cs.setLong(1, productId);
            cs.setInt(2, quantity);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Orders> getAllOrders() {
        List<Orders> ordersList = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_all_orders(?)}");
            cs.registerOutParameter(1, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(1);
            while (rs.next()) {
                Orders order = new Orders();
                order.setId(rs.getLong("order_id"));
                order.setProductId(rs.getLong("product_id"));
                order.setProductName(rs.getString("product_name"));
                order.setQuantity(rs.getInt("quantity"));
                order.setTotalPrice(rs.getDouble("total_price"));
                ordersList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ordersList;
    }

    public Orders getOrderById(Long orderId) {
        Orders order = null;
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_order_by_id(?, ?)}");
            cs.setLong(1, orderId);
            cs.registerOutParameter(2, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs.next()) {
                order = new Orders();
                order.setId(rs.getLong("order_id"));
                order.setProductId(rs.getLong("product_id"));
                order.setProductName(rs.getString("product_name"));
                order.setQuantity(rs.getInt("quantity"));
                order.setTotalPrice(rs.getDouble("total_price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return order;
    }

    public void updateOrder(Long orderId, Long productId, int quantity) {
        ProductResponse product = productClient.getProductById(productId);
        if (product.getStock() < quantity) {
            throw new RuntimeException("Insufficient stock to update the order.");
        }

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call update_order(?, ?, ?)}");
            cs.setLong(1, orderId);
            cs.setLong(2, productId);
            cs.setInt(3, quantity);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteOrder(Long orderId) {
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call delete_order(?)}");
            cs.setLong(1, orderId);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
