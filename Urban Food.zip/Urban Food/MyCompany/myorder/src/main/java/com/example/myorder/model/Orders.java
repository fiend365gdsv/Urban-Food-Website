package com.example.myorder.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "orders")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id") // Ensures mapping aligns with Oracle DB column
    private Long id;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Transient // Not persisted in DB; fetched from Product service
    private String productName;

    @Column(nullable = false)
    private int quantity;

    @Column(name = "total_price", nullable = false)
    private double totalPrice;
}
