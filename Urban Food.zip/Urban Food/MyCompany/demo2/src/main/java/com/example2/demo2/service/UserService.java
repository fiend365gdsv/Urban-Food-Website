package com.example2.demo2.service;

import com.example2.demo2.dto.UserDTO;
import com.example2.demo2.model.User;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService {

    private final DataSource dataSource;
    private final ModelMapper modelMapper;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserDTO registerUser(UserDTO userDTO) {
        // Encrypt the password
        String encryptedPassword = passwordEncoder.encode(userDTO.getPassword());
        userDTO.setPassword(encryptedPassword);

        // Default role if not provided
        if (userDTO.getRole() == null || userDTO.getRole().isEmpty()) {
            userDTO.setRole("MANAGER");
        }

        try (Connection conn = dataSource.getConnection()) {
            // Prepare the callable statement for stored procedure
            CallableStatement cs = conn.prepareCall("{call add_users(?, ?, ?, ?, ?, ?)}");

            cs.setString(1, userDTO.getUserName());
            cs.setString(2, userDTO.getEmail());
            cs.setString(3, encryptedPassword);
            cs.setString(4, userDTO.getRole());
            cs.setString(5, userDTO.getAddress());
            cs.setString(6, userDTO.getPhone());

            // Execute the stored procedure
            cs.execute();

        } catch (SQLException e) {
            // Handle specific exception for unique constraint violation
            if (e.getErrorCode() == 20001) {
                // Handle username already exists error
                throw new RuntimeException("Username already exists.");
            } else if (e.getErrorCode() == 20002) {
                // Handle email already exists error
                throw new RuntimeException("Email already exists.");
            } else {
                // For other SQL errors, print stack trace and throw an exception
                e.printStackTrace();
                throw new RuntimeException("An unexpected error occurred while registering the user.");
            }
        }

        return userDTO;
    }

    public List<UserDTO> getAllUsers() {
        List<UserDTO> userList = new ArrayList<>();

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_all_users(?)}");
            cs.registerOutParameter(1, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(1);
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getLong("id"));
                user.setUserName(rs.getString("user_name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                user.setAddress(rs.getString("address"));
                user.setPhone(rs.getString("phone"));
                userList.add(modelMapper.map(user, UserDTO.class));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error fetching users.");
        }

        return userList;
    }

    public UserDTO getUserById(Long id) {
        User user = new User();

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_user_by_id(?, ?)}");
            cs.setLong(1, id);
            cs.registerOutParameter(2, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs.next()) {
                user.setId(rs.getLong("id"));
                user.setUserName(rs.getString("user_name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                user.setAddress(rs.getString("address"));
                user.setPhone(rs.getString("phone"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error fetching user by ID.");
        }

        return modelMapper.map(user, UserDTO.class);
    }

    public UserDTO updateUser(UserDTO userDTO) {
        // Encrypt the password
        String encryptedPassword = passwordEncoder.encode(userDTO.getPassword());
        userDTO.setPassword(encryptedPassword);

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call update_users(?, ?, ?, ?, ?, ?, ?)}");

            cs.setLong(1, userDTO.getId());
            cs.setString(2, userDTO.getUserName());
            cs.setString(3, userDTO.getEmail());
            cs.setString(4, encryptedPassword);
            cs.setString(5, userDTO.getRole());
            cs.setString(6, userDTO.getAddress());
            cs.setString(7, userDTO.getPhone());

            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error updating user.");
        }

        return userDTO;
    }

    public String deleteUser(Long id) {
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call delete_users(?)}");
            cs.setLong(1, id);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            return "Failed to delete user.";
        }

        return "User deleted successfully.";
    }
}
