package com.example.mydelevery.dto;

import lombok.Data;

@Data
public class OrderResponseDto {
    private Long id;
}
