package com.example.mydelevery.dto;

import lombok.Data;

@Data
public class DeliveryRequestDto {
    private Long customerId;
    private Long orderId;
    private String deliveryStatus;
}
