package com.example.mydelevery.controller;

import com.example.mydelevery.dto.DeliveryRequestDto;
import com.example.mydelevery.dto.DeliveryResponseDto;
import com.example.mydelevery.dto.DeliveryUpdateRequest;
import com.example.mydelevery.model.Delivery;
import com.example.mydelevery.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/deliveries")
@RequiredArgsConstructor
public class DeliveryController {

    private final DeliveryService deliveryService;

    @PostMapping("/add")
    public ResponseEntity<String> addDelivery(@RequestBody DeliveryRequestDto dto) {
        deliveryService.addDelivery(dto);
        return ResponseEntity.ok("Delivery added successfully.");
    }

    @GetMapping("/{id}")
    public ResponseEntity<DeliveryResponseDto> getDelivery(@PathVariable Long id) {
        DeliveryResponseDto delivery = deliveryService.getDeliveryById(id);
        return delivery != null ? ResponseEntity.ok(delivery) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateDelivery(
            @PathVariable Long id,
            @RequestBody DeliveryUpdateRequest request) {

        Delivery delivery = new Delivery();
        delivery.setDeliveryId(id);
        delivery.setCustomerId(request.getCustomerId());
        delivery.setOrderId(request.getOrderId());
        delivery.setDeliveryStatus(request.getDeliveryStatus());

        deliveryService.updateDelivery(delivery);
        return ResponseEntity.ok("Delivery updated successfully.");
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDelivery(@PathVariable Long id) {
        deliveryService.deleteDelivery(id);
        return ResponseEntity.ok("Delivery deleted successfully.");
    }
    @GetMapping("/all")
    public ResponseEntity<List<DeliveryResponseDto>> getAllDeliveries() {
        return ResponseEntity.ok(deliveryService.getAllDeliveries());
    }

}
