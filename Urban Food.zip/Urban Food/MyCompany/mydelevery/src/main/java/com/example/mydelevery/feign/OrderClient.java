package com.example.mydelevery.feign;

import com.example.mydelevery.dto.OrderResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "order-service", url = "http://localhost:8080")
public interface OrderClient {

    @GetMapping("/orders/{id}")
    OrderResponseDto getOrderById(@PathVariable("id") Long id);
}
