package com.example.mydelevery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delivery {
    private Long deliveryId;
    private Long customerId;
    private Long orderId;
    private String address;
    private String deliveryStatus;
}
