package com.example.mydelevery.repository;
import com.example.mydelevery.model.Delivery;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Optional;
@Repository
@RequiredArgsConstructor

public class DeliveryRepository {

    private final JdbcTemplate jdbcTemplate;

    public void addDelivery(Delivery delivery) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("add_delivery");
        call.execute(
                Map.of("p_customer_id", delivery.getCustomerId(),
                        "p_order_id", delivery.getOrderId(),
                        "p_address", delivery.getAddress(),
                        "p_status", delivery.getDeliveryStatus())
        );
    }

    public Delivery getDeliveryById(Long id) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_delivery_by_id")
                .returningResultSet("p_cursor", (ResultSet rs, int rowNum) -> {
                    Delivery d = new Delivery();
                    d.setDeliveryId(rs.getLong("delivery_id"));
                    d.setCustomerId(rs.getLong("customer_id"));
                    d.setOrderId(rs.getLong("order_id"));
                    d.setAddress(rs.getString("address"));
                    d.setDeliveryStatus(rs.getString("delivery_status"));
                    return d;
                });

        Map<String, Object> result = call.execute(Map.of("p_delivery_id", id));
        var deliveries = (java.util.List<Delivery>) result.get("p_cursor");
        return deliveries.isEmpty() ? null : deliveries.get(0);
    }

    public void updateDelivery(Delivery delivery) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("update_delivery");

        Map<String, Object> params = new HashMap<>();
        params.put("p_delivery_id", delivery.getDeliveryId());
        params.put("p_customer_id", delivery.getCustomerId());
        params.put("p_order_id", delivery.getOrderId());
        params.put("p_status", delivery.getDeliveryStatus());

        call.execute(params);
    }

    public void deleteDelivery(Long id) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_delivery");
        call.execute(Map.of("p_delivery_id", id));
    }
    public List<Delivery> getAllDeliveries() {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_all_deliveries")
                .returningResultSet("p_cursor", (ResultSet rs, int rowNum) -> {
                    Delivery d = new Delivery();
                    d.setDeliveryId(rs.getLong("delivery_id"));
                    d.setCustomerId(rs.getLong("customer_id"));
                    d.setOrderId(rs.getLong("order_id"));
                    d.setAddress(rs.getString("address"));
                    d.setDeliveryStatus(rs.getString("delivery_status"));
                    return d;
                });

        Map<String, Object> result = call.execute();
        return (List<Delivery>) result.get("p_cursor");
    }

}