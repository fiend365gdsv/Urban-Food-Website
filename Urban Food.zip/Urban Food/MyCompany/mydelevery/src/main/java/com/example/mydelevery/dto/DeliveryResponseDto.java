package com.example.mydelevery.dto;

import lombok.Data;

@Data
public class DeliveryResponseDto {
    private Long deliveryId;
    private Long customerId;
    private Long orderId;
    private String address;
    private String deliveryStatus;
}
