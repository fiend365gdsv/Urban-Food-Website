package com.example.mydelevery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.example.mydelevery.feign")
public class MydeleveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MydeleveryApplication.class, args);
	}
}
