package com.example.mydelevery.dto;

import lombok.Data;

@Data
public class DeliveryUpdateRequest {
    private Long customerId;
    private Long orderId;
    private String deliveryStatus;
}

