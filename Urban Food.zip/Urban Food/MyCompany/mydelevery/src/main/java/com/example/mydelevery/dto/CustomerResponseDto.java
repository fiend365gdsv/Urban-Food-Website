package com.example.mydelevery.dto;

import lombok.Data;

@Data
public class CustomerResponseDto {
    private Long id;
    private String address;
}
