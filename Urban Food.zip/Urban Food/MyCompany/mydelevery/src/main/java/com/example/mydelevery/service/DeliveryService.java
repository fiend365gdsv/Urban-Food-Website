package com.example.mydelevery.service;

import com.example.mydelevery.dto.*;
import com.example.mydelevery.feign.CustomerClient;
import com.example.mydelevery.feign.OrderClient;
import com.example.mydelevery.model.Delivery;
import com.example.mydelevery.repository.DeliveryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DeliveryService {

    private final DeliveryRepository deliveryRepository;
    private final CustomerClient customerClient;
    private final OrderClient orderClient;

    public void addDelivery(DeliveryRequestDto dto) {
        CustomerResponseDto customer = customerClient.getCustomerById(dto.getCustomerId());
        Delivery delivery = new Delivery();
        delivery.setCustomerId(dto.getCustomerId());
        delivery.setOrderId(dto.getOrderId());
        delivery.setAddress(customer.getAddress());
        delivery.setDeliveryStatus(dto.getDeliveryStatus());
        deliveryRepository.addDelivery(delivery);
    }

    public DeliveryResponseDto getDeliveryById(Long id) {
        Delivery delivery = deliveryRepository.getDeliveryById(id);
        if (delivery == null) return null;

        DeliveryResponseDto response = new DeliveryResponseDto();
        response.setDeliveryId(delivery.getDeliveryId());
        response.setCustomerId(delivery.getCustomerId());
        response.setOrderId(delivery.getOrderId());
        response.setAddress(delivery.getAddress());
        response.setDeliveryStatus(delivery.getDeliveryStatus());

        return response;
    }

    public void updateDelivery(Delivery delivery) {
        deliveryRepository.updateDelivery(delivery);
    }

    public void deleteDelivery(Long id) {
        deliveryRepository.deleteDelivery(id);
    }
    public List<DeliveryResponseDto> getAllDeliveries() {
        List<Delivery> deliveries = deliveryRepository.getAllDeliveries();
        return deliveries.stream().map(delivery -> {
            String address;
            try {
                address = customerClient.getCustomerById(delivery.getCustomerId()).getAddress();
            } catch (feign.FeignException.NotFound ex) {
                address = "Address not found"; // or you can put null, or "Unknown address"
            }
            DeliveryResponseDto dto = new DeliveryResponseDto();
            dto.setDeliveryId(delivery.getDeliveryId());
            dto.setCustomerId(delivery.getCustomerId());
            dto.setOrderId(delivery.getOrderId());
            dto.setAddress(address);
            dto.setDeliveryStatus(delivery.getDeliveryStatus());
            return dto;
        }).toList();
    }


}
