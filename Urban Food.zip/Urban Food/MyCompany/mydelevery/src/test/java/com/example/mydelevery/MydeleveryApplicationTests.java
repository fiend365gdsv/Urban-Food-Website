package com.example.mydelevery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydeleveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
