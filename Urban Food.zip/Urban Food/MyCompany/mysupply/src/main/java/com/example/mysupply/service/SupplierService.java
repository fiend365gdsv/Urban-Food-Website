package com.example.mysupply.service;

import com.example.mysupply.model.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

@Service
public class SupplierService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Supplier addSupplier(Supplier supplier) {
        jdbcTemplate.update("{ call add_suppliers(?, ?, ?, ?, ?) }",
                supplier.getId(),
                supplier.getName(),
                supplier.getContactNumber(),
                supplier.getEmail(),
                supplier.getAddress());
        return supplier;
    }

    public Supplier updateSupplier(Long id, Supplier updatedSupplier) {
        jdbcTemplate.update("{ call update_suplliers(?, ?, ?, ?, ?) }",
                id,
                updatedSupplier.getName(),
                updatedSupplier.getContactNumber(),
                updatedSupplier.getEmail(),
                updatedSupplier.getAddress());
        return updatedSupplier;
    }

    public Supplier getSupplierById(Long id) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_supplier_by_id")
                .declareParameters(
                        new SqlOutParameter("result_cursor", oracle.jdbc.OracleTypes.CURSOR,
                                (ResultSet rs, int rowNum) -> mapRowToSupplier(rs)));

        Map<String, Object> result = jdbcCall.execute(id);
        List<Supplier> suppliers = (List<Supplier>) result.get("result_cursor");
        return suppliers != null && !suppliers.isEmpty() ? suppliers.get(0) : null;
    }

    public List<Supplier> getAllSuppliers() {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("get_all_suppliers")
                .declareParameters(new SqlOutParameter("result_cursor", oracle.jdbc.OracleTypes.CURSOR,
                        (ResultSet rs, int rowNum) -> mapRowToSupplier(rs)));

        Map<String, Object> result = jdbcCall.execute();
        return (List<Supplier>) result.get("result_cursor");
    }

    public String deleteSupplier(Long id) {
        jdbcTemplate.update("{ call delete_suppliers(?) }", id);
        return "Supplier with ID " + id + " deleted successfully";
    }

    private Supplier mapRowToSupplier(ResultSet rs) throws SQLException {
        Supplier supplier = new Supplier();
        supplier.setId(rs.getLong("id"));
        supplier.setName(rs.getString("supplier_name"));
        supplier.setContactNumber(rs.getString("contact_number"));
        supplier.setEmail(rs.getString("email"));
        supplier.setAddress(rs.getString("address"));
        return supplier;
    }
}
