package com.example.mysupply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysupplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
