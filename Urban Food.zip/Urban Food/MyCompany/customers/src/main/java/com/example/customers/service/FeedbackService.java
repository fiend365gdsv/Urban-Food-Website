package com.example.customers.service;

import com.example.customers.dto.FeedbackDto;
import com.example.customers.model.Feedback;
import com.example.customers.repository.FeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final ModelMapper modelMapper = new ModelMapper();

    public FeedbackDto addFeedback(FeedbackDto feedbackDto) {
        Feedback feedback = modelMapper.map(feedbackDto, Feedback.class);

        String createdAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        feedback.setCreatedAt(createdAt);

        Feedback savedFeedback = feedbackRepository.save(feedback);
        return modelMapper.map(savedFeedback, FeedbackDto.class);
    }

    public List<FeedbackDto> getFeedbacksByCustomerId(Long customerId) {
        List<Feedback> feedbacks = feedbackRepository.findByCustomerId(customerId);
        return feedbacks.stream()
                .map(f -> modelMapper.map(f, FeedbackDto.class))
                .collect(Collectors.toList());
    }

    public List<FeedbackDto> getAllFeedbacks() {
        List<Feedback> feedbacks = feedbackRepository.findAll();
        return feedbacks.stream()
                .map(f -> modelMapper.map(f, FeedbackDto.class))
                .collect(Collectors.toList());
    }

    public void deleteFeedback(String feedbackId) {
        feedbackRepository.deleteById(feedbackId);
    }

    public FeedbackDto updateFeedback(String feedbackId, FeedbackDto feedbackDto) {
        Feedback feedback = feedbackRepository.findById(feedbackId)
                .orElseThrow(() -> new RuntimeException("Feedback not found"));

        feedback.setFeedbackText(feedbackDto.getFeedbackText());
        feedback.setRating(feedbackDto.getRating());

        Feedback updatedFeedback = feedbackRepository.save(feedback);
        return modelMapper.map(updatedFeedback, FeedbackDto.class);
    }
}
