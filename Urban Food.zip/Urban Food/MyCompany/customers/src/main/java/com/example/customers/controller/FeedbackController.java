package com.example.customers.controller;

import com.example.customers.dto.FeedbackDto;
import com.example.customers.model.Feedback;
import com.example.customers.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/feedbacks")
@RequiredArgsConstructor
public class FeedbackController {

    private final FeedbackService feedbackService;

    @PostMapping("/add")
    public ResponseEntity<FeedbackDto> addFeedback(@RequestBody FeedbackDto feedbackDto) {
        FeedbackDto feedback = feedbackService.addFeedback(feedbackDto);
        return ResponseEntity.ok(feedback);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<FeedbackDto>> getFeedbacksByCustomer(@PathVariable Long customerId) {
        List<FeedbackDto> feedbacks = feedbackService.getFeedbacksByCustomerId(customerId);
        return ResponseEntity.ok(feedbacks);
    }

    @GetMapping("/all")
    public ResponseEntity<List<FeedbackDto>> getAllFeedbacks() {
        List<FeedbackDto> feedbacks = feedbackService.getAllFeedbacks();
        return ResponseEntity.ok(feedbacks);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFeedback(@PathVariable String id) {
        feedbackService.deleteFeedback(id);
        return ResponseEntity.ok("Feedback deleted successfully");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<FeedbackDto> updateFeedback(@PathVariable String id, @RequestBody FeedbackDto feedbackDto) {
        FeedbackDto feedback = feedbackService.updateFeedback(id, feedbackDto);
        return ResponseEntity.ok(feedback);
    }
}
