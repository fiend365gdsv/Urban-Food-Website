package com.example.customers.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "feedbacks")
public class Feedback {

    @Id
    private String id; // MongoDB ID

    private Long customerId; // From your Oracle customer

    private String feedbackText;

    private int rating; // 1 to 5 stars

    private String createdAt;
}
