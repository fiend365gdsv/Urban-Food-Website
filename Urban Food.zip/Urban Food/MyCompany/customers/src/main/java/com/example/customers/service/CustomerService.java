package com.example.customers.service;

import com.example.customers.dto.CustomerDTO;
import com.example.customers.model.Customer;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final DataSource dataSource;
    private final ModelMapper modelMapper;
    private final BCryptPasswordEncoder passwordEncoder;

    public void registerCustomer(CustomerDTO customerDTO) {
        Customer customer = modelMapper.map(customerDTO, Customer.class);
        customer.setPassword(passwordEncoder.encode(customerDTO.getPassword()));

        try (Connection conn = dataSource.getConnection()) {
            // Call procedure with 5 parameters (no ID)
            CallableStatement cs = conn.prepareCall("{call add_customer(?, ?, ?, ?, ?, ?)}");

            cs.setString(1, customer.getFirst_name());
            cs.setString(2, customer.getLast_name());
            cs.setString(3, customer.getEmail());
            cs.setString(4, customer.getPassword());
            cs.setString(5, customer.getPhone());
            cs.setString(6, customer.getAddress());

            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Optional<Customer> findCustomerById(Long id) {
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_customer_by_id(?, ?)}");
            cs.setLong(1, id);
            cs.registerOutParameter(2, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs != null && rs.next()) {
                Customer customer = new Customer();
                customer.setId(rs.getLong("id"));
                customer.setFirst_name(rs.getString("first_name"));
                customer.setLast_name(rs.getString("last_name"));
                customer.setEmail(rs.getString("email"));
                customer.setPassword(rs.getString("password"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                return Optional.of(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public void updateCustomer(CustomerDTO customerDTO, Long id) {
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call update_customer(?, ?, ?, ?, ?, ?, ?)}");

            cs.setLong(1, id);
            cs.setString(2, customerDTO.getFirst_name());
            cs.setString(3, customerDTO.getLast_name());
            cs.setString(4, customerDTO.getEmail());
            cs.setString(5, passwordEncoder.encode(customerDTO.getPassword()));
            cs.setString(6, customerDTO.getPhone());
            cs.setString(7, customerDTO.getAddress());

            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(Long id) {
        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call delete_customer(?)}");
            cs.setLong(1, id);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();

        try (Connection conn = dataSource.getConnection()) {
            CallableStatement cs = conn.prepareCall("{call get_all_customers(?)}");
            cs.registerOutParameter(1, Types.REF_CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(1);
            while (rs != null && rs.next()) {
                Customer customer = new Customer();
                customer.setId(rs.getLong("id"));
                customer.setFirst_name(rs.getString("first_name"));
                customer.setLast_name(rs.getString("last_name"));
                customer.setEmail(rs.getString("email"));
                customer.setPassword(rs.getString("password"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customers;
    }
}
