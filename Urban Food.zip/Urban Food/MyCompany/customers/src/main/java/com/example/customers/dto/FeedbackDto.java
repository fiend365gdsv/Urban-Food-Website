package com.example.customers.dto;

import lombok.Data;

@Data
public class FeedbackDto {
    private String id;
    private Long customerId;
    private String feedbackText;
    private int rating;
    private String createdAt;
}
